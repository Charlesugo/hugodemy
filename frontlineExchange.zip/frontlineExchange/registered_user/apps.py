from django.apps import AppConfig


class RegisteredUserConfig(AppConfig):
    name = 'registered_user'
